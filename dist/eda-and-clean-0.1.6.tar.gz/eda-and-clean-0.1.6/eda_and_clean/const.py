class std_vals:
    na_like_items_in_str = [
        "na",
        "n/a",
        "nan",
        "none",
        "null",
        "missing",
        "unknown",
        "undefined",
        "",
        " ",
        "  ",
        "   ",
    ]
